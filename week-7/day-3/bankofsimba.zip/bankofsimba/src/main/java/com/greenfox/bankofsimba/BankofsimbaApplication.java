package com.greenfox.bankofsimba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankofsimbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankofsimbaApplication.class, args);
	}
}
